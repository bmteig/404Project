#include "stdafx.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <map>
#include <vector>
#include <algorithm>

using namespace std;

class Vehicle {
private:

	int id;
	int type;
	int zipcode;
	int distance;				// temp var used to hold distance to a request ZIP
	bool isAvailable = true;	// 0/F = assigned, 1/T = available
								// functions to sort vector based on different variables
	friend bool compareVehicleZip(Vehicle a, Vehicle b);
	friend bool compareVehicleDistance(Vehicle a, Vehicle b);
	friend bool compareVehicleId(Vehicle a, Vehicle b);

public:

	int getId() {
		return id;
	}
	int getType() {
		return type;
	}
	int getZip() {
		return zipcode;
	}
	bool getAvailability() {
		return isAvailable;
	}

	int getDistance() {
		return distance;
	}

	void setAvailability(bool b) {		// change availability of vehicle
		isAvailable = b;
	}

	void setZip(int zip) {
		zipcode = zip;
	}

	void setDistance(int d) {
		distance = d;
	}

	Vehicle() {}

	Vehicle(int vId, int vType, int vZip) {
		id = vId;
		type = vType;
		zipcode = vZip;
	}
};

class Request {
private: 

	int id;
	int type;
	int zipcode;
	int distance;				// time for closest vehicle to travel to emergency site
	bool hasVehicle = false;    // var used for easy printing
	string description;			// added description of emergency
	Vehicle vehicle;

public:

	int getId() {
		return id;
	}
	int getType() {
		return type;
	}
	int getZip() {
		return zipcode;
	}
	int getDistance() {
		return distance;
	}
	string getDescription() {
		return description;
	}
	int getVehicleId() {
		return vehicle.getId();
	}

	bool rHasVehicle() {
		return hasVehicle;
	}
	void setHasVehicle(bool b) {
		hasVehicle = b;
	}

	void setVehicle(Vehicle &v) {
		vehicle = v;					// assign vehicle to request
		distance = v.getDistance();		// update distance variable
	}

	Request(int rId, int rType, int rZip, string rDes) {
		id = rId;
		type = rType;
		zipcode = rZip;
		description = rDes;
	}
};

string getTypeName(int type) {		// string version of emergency/vehicle type for readability, O(1)
	string vName;

	switch (type) {
	case 1:
		vName = "Ambulance";
		break;
	case 2:
		vName = "Fire Truck";
		break;
	case 3:
		vName = "Police Car";
		break;
	default:
		vName = "Invalid ID";
		break;
	}
	return vName;
}

string getAvailabilityName(bool b) {	// string version of availability var for readability, O(1)
	string a;
	if (b) {
		a = "Available";
	}
	else { a = "Assigned"; }
	return a;
}

void printHeader() {		// print title and other spacing
	cout << right << setfill('_') << setw(50) << "" << "Emergency Vehicle Scheduler" << setw(50) << "" << endl;
	cout << endl << endl;
}

void printVehicle(Vehicle &v) {		// method to print vehicle attributes
	cout << left << setw(5) << v.getId() << setw(12);
	cout << left << getTypeName(v.getType()) << " (" << v.getType() << setw(3) << ")";
	cout << left << setw(10) << v.getZip() << setw(12) << getAvailabilityName(v.getAvailability()) << endl;
}

void printVehicles(vector<Vehicle> &vList) {	// method to print vehicles table, O(n)
	sort(vList.begin(), vList.end(), compareVehicleId);	// sort by ID for clean printing
	cout << right << setfill('_') << setw(25) << "Vehicles" << setfill('_') << setw(25) << "" << endl;
	cout << left << setfill(' ') << setw(5) << "ID" << setw(18);
	cout << left << "Vehicle Type (#)";
	cout << left << setw(10) << "ZIP Code" << setw(10) << "Availability" << endl;
	for (int i = 0; i < vList.size(); i++) {
		printVehicle(vList[i]);
	}
	cout << endl;
}

void printRequest(Request &r) {		// method to print request attributes
	string d;						// helper vars for easy printing when vehicle is not yet assigned.
	string v;
	if (!(r.rHasVehicle())) {
		d = "--";
		v = "--";
	}
	else { 
		d = to_string(r.getDistance());
		v = to_string(r.getVehicleId());
	}

	cout << left << setw(5) << r.getId() << setw(14);
	cout << left << getTypeName(r.getType()) << " (" << r.getType() << setw(3) << ")";
	cout << left << setw(10) << r.getZip() << setw(15) << d << setw(12);
	cout << left << v << setw(30) << r.getDescription() << endl;
}

void printRequests(vector<Request> &rList) {	// method to print requests table, O(n)
	cout << right << setfill('_') << setw(38) << "Requests" << setfill('_') << setw(38) << "" << endl;
	cout << left << setfill(' ') << setw(5) << "ID" << setw(20);
	cout << left << "Emergency Type (#)";
	cout << left << setw(10) << "ZIP Code" << setw(15) << "Distance (mi)" << setw(12);
	cout << left << "Vehicle ID" << setw(30);
	cout << left << "Description" << endl;
	for (int i = 0; i < rList.size(); i++) {
		printRequest(rList[i]);
	}
	cout << endl;
}

template<typename Z, typename D>		// template class for using range based for loop
void printZips(map<Z, D> const &m) {	// prints zipMap, O(n)
	cout << left << "________ZIP Codes and Distances________";
	cout << setw(20) << "" << endl;
	cout << left << setw(12) << "ZIP Code 1" << setw(12) << "ZIP Code 2";
	cout << left << setw(15) << "Distance (mi)" << endl;

	for (auto const& pair : m) {
		cout << left << setw(12) << pair.first << setw(12) << (pair.first) + 1;
		cout << left << setw(15) << pair.second << endl;
	}

	cout << endl;
}

void loadMap(map<int, int> &m) {			// each pair holds a key-value pair of zip code and distance
	m.insert(pair<int, int>(64050, 2));		// the key indicates the distance from the given zip code
	m.insert(pair<int, int>(64051, 2));		// to the next adjacent zip code. For example, int pair
	m.insert(pair<int, int>(64052, 3));		// (64055, 2) designates that the distance from zip code
	m.insert(pair<int, int>(64053, 1));		// 64055 to 64056 is 2 (miles)	
	m.insert(pair<int, int>(64054, 5));		
	m.insert(pair<int, int>(64055, 6));		
	m.insert(pair<int, int>(64056, 4));		
	m.insert(pair<int, int>(64057, 8));		
	m.insert(pair<int, int>(64058, 3));
	m.insert(pair<int, int>(64059, 3));	
	m.insert(pair<int, int>(64060, 3));
	m.insert(pair<int, int>(64061, 4));
	m.insert(pair<int, int>(64062, 4));
	m.insert(pair<int, int>(64063, 5));
	m.insert(pair<int, int>(64064, 8));
	m.insert(pair<int, int>(64065, 9));
	m.insert(pair<int, int>(64066, 4));
	m.insert(pair<int, int>(64067, 6));
	m.insert(pair<int, int>(64068, 9));
	m.insert(pair<int, int>(64069, 2));
	m.insert(pair<int, int>(64070, 1));
}

void loadVehicles(vector<Vehicle> &vList) {	// load Vehicle vector
	
	vList.push_back(Vehicle(1, 1, 64050));
	vList.push_back(Vehicle(2, 1, 64052));
	vList.push_back(Vehicle(3, 1, 64054));
	vList.push_back(Vehicle(4, 1, 64061));
	vList.push_back(Vehicle(5, 1, 64066));
	vList.push_back(Vehicle(6, 2, 64051));
	vList.push_back(Vehicle(7, 2, 64068));
	vList.push_back(Vehicle(8, 2, 64070));
	vList.push_back(Vehicle(9, 2, 64053));
	vList.push_back(Vehicle(10, 2, 64062));
	vList.push_back(Vehicle(11, 3, 64067));
	vList.push_back(Vehicle(12, 3, 64060));
	vList.push_back(Vehicle(13, 3, 64062));
	vList.push_back(Vehicle(14, 3, 64061));
	vList.push_back(Vehicle(15, 3, 64063));
}

void loadRequests(vector<Request> &rList) {		// load Request vector

	rList.push_back(Request(1, 2, 64052, "Cat in tree"));
	rList.push_back(Request(2, 3, 64056, "Burglary"));
	rList.push_back(Request(3, 1, 64053, "Ladder Accident"));
	rList.push_back(Request(4, 3, 64062, "Car Chase"));
	rList.push_back(Request(5, 2, 64065, "House Fire"));
	rList.push_back(Request(6, 1, 64050, "Asthma Attack"));
	rList.push_back(Request(7, 2, 64057, "Chemical Plant Explosion"));
	rList.push_back(Request(8, 3, 64052, "Domestic Call"));
	rList.push_back(Request(9, 3, 64061, "Locked Keys in Car"));
	rList.push_back(Request(10, 3, 64059, "Walk Student Home"));
	rList.push_back(Request(11, 3, 64068, "Direct Traffic"));
}

bool compareVehicleZip(Vehicle a, Vehicle b) // function to sort vehicles by ZIP code, sort: O(n lgn)
{
	return (a.zipcode < b.zipcode);
}

bool compareVehicleDistance(Vehicle a, Vehicle b) // function to compare vehicles by distance, sort: O(n lgn)
{
	return (a.distance < b.distance);
}

bool compareVehicleId(Vehicle a, Vehicle b) // function to compare vehicles by id, sort: O(n lgn)
{
	return (a.id < b.id);
}

void getProperVehicles(vector<Vehicle> &vList, vector<Vehicle> &pList, int type) {
										// gets proper vehicle types based on request type, O(n)
	for (int i = 0; i < vList.size(); i++) {	// look at each element in list
		if ((vList[i].getType() == type) && (vList[i].getAvailability() == true)) {	
												// if vehicle is of the right type and is available
			pList.push_back(vList[i]);			// add to Proper list
		}
	}
}

int findMidPoint(vector<Vehicle> &vList, int low, int high, int z) {	// binary search for zipcode
										// z represents the zip code to be found, O(n lgn)
	if (vList[high].getZip() <= z)		// marginal cases
		return high;
	if (vList[low].getZip() > z)
		return low;
								  // Find the mid point
	int mid = (low + high) / 2; 
								 // If zip code is middle element, then return mid 
	if (vList[mid].getZip() <= z && vList[mid + 1].getZip() > z) {
		return mid;
	}
								// If z is greater than mid, then look in right half for zip
	if (vList[mid].getZip() < z) {
		return findMidPoint(vList, mid + 1, high, z);
	}							// else, look in left half
	return findMidPoint(vList, low, mid - 1, z);
}

void getKClosest(vector<Vehicle> &vList, int z, int k, int n, vector<Vehicle> &vClosest)
{							// gets closest k (6) elements from "midpoint" (request zip)
							// Complexity of findMidPoint + complexity of getting k elements
							// O(n lgn) + O(k) = O (n lgn) + O(1). Thus, complexity is O(n lgn).
					// Find the mid point to calculate search "bounds"
	int l = findMidPoint(vList, 0, n - 1, z); 
	int r = l + 1;   // Right bound to search 
	int count = 0; // Count of elements found, used to keep track if it less than k (6)

				   // If zip is present in the list, add to list and return early (since there is a vehicle there)
	if (vList[l].getZip() == z) { 
		vClosest.push_back(vList[l]);
		return;
	}
					// Compare elements on left and right of midpoint to find the k (6) closest elements 
	while (l >= 0 && r < n && count < k)
	{
		if (z - vList[l].getZip() < vList[r].getZip() - z) {
			vClosest.push_back(vList[l--]);		// add element to Closest list
		}							// decrease left bound
		else {
			vClosest.push_back(vList[r++]);
		}							// increase right bound
		count++;							// increase count of elements chosen
	}

	// If at end of list, get rest of k elements from left side
	while (count < k && l >= 0) {
		vClosest.push_back(vList[l--]);
		count++;
	}

	// If there at beginning of list, get rest of k elements from right side 
	while (count < k && r < n) {
		vClosest.push_back(vList[r++]);
		count++;
	}
}

int getDistance(int vZip, int destZip, map<int, int> &m) {
				// recursive algorithm to determine distance between vehicle and request ZIPs
				// O(n*m) where n = number of zips in array and m = number of zip codes
				// Since n is at max 6, worst case is O(6m). Thus, complexity is O(m).

	int distance = 0;
	
	if (vZip == destZip) {					// if vehicle is in same ZIP code, return 0 distance
		return 0;
	} // if difference is one, return distance from smaller to larger ZIP code (see map function for more detail)
	else if ((vZip - destZip) == 1) {		// if vehicle is in directly "above" ZIP code
		return m.at(destZip);				//return distance from the previous (destination) to this one
	}
	else if ((destZip - vZip) == 1) {	// if vehicle is in directly "below" ZIP code
		return m.at(vZip);				// return distance from this to the next (destination) one
	}
	else if (vZip > destZip) {			// if vehicle is in another "higher" ZIP code
		distance = m.at((vZip - 1));	// get distance from previous ZIP code to this one
		return distance + getDistance((vZip - 1), destZip, m);
										// backtrack to sum up distances from dest to this one
	}
	else if (vZip < destZip) {			// if vehicle is in another "lower" ZIP code
		distance = m.at((vZip));	// get distance to next ZIP code
		return distance + getDistance((vZip + 1), destZip, m);
		// sum up distances from this ZIP code to the destination one
	}
	else {
		cout << "Error getting distance";
		return 0;
	}
}

void getDistances(vector<Vehicle> &vClosest, int size, int destZip, map<int, int> &m) {
	for (int i = 0; i < size; i++) {	// method to get distances for each vehicle in the Closest list, O(n)
		int distance = getDistance(vClosest[i].getZip(), destZip, m);
		vClosest[i].setDistance(distance);	// assign vehicle distance to vehicle
	}
}

void updateVehicle(vector<Vehicle> &vList, int id, bool b) {	// updates main vehicle vector by ID, O(n)
	for (int i = 0; i < vList.size(); i++) {		// search through vector to match ID
		if (vList[i].getId() == id) {				
			vList[i].setAvailability(b);			// update availability
		}
	}
}

void updateRequest(Request &r, Vehicle v, bool b) {				// updates request to update in main list
	r.setVehicle(v);											// closest vehicle and assign to request
	r.setHasVehicle(b);											// update print var
}

void getClosestVehicle(vector<Vehicle> &vList, Request &r, map<int, int> &m) {
	// Main algorithm process (separated into different functions):
	// Get all available vehicles of needed type
	// Sort vehicle list by ZIP
	// Split vehicle list to get 6 closest vehicles (about +/- 3 from given) to given zipcode using binary search
	// This may not always be ideal (sub-optimal), but seems to generally get
	// the closest vehicle for each of these vehicles, calculate the distance using the zip code map
	// Take the lowest distance (as this will be the closest vehicle)
	// Assign this vehicle to the request, remove from available list, and update the request distance variable
	
	vector<Vehicle> vProper;			// list of the available and proper type of vehicles for the request
	vector<Vehicle> vClosest;			// list of closest elements
	int destZip = r.getZip();			// zip code to match
	int k = 6;							// number of elements to return from search
	
	getProperVehicles(vList, vProper, r.getType());		// get right vehicles

	if (vProper.size() == 0) {							// if no availble vehicles, tell user
		cout << "-- No available vehicle for Request ID#" << r.getId() << " --" << endl;
	}
	else {												// if vehicles are available, find closest		
		getKClosest(vProper, destZip, k, vProper.size(), vClosest);
		// get numerically "closest" ZIP codes to given request ZIP code
		getDistances(vClosest, vClosest.size(), destZip, m);	// get actual distance between ZIP codes
		sort(vClosest.begin(), vClosest.end(), compareVehicleDistance);		// sort vehicles by distance, get
		
		int c = vClosest[0].getId();								// set vehicle availability in main list by ID
		updateVehicle(vList, c, false);
		updateRequest(r, vClosest[0], true);
	}
}

void resolveRequests(vector<Vehicle> &vList, vector<Request> &rList, map<int, int> &m) {
	cout << right << setfill('*') << setw(40) << "Scheduling Issues" << setw(40) << ' ' << endl << endl;
	sort(vList.begin(), vList.end(), compareVehicleZip);	// sort vehicles by ZIP code
	for (int i = 0; i < rList.size(); i++) {
		getClosestVehicle(vList, rList[i], m);				// get closest vehicle for each request, O(n)
	}
	cout << endl;
}

int main()
{
	map<int, int> zMap;			// ZIP code distance map
	vector<Vehicle> vList;		// list of emergency vehicles
	vector<Request> rList;		// list of emergency requests
	loadMap(zMap);				// load each map/vector
	loadVehicles(vList);
	loadRequests(rList);
	
								// print title and starter tables
	printHeader();
	cout << setfill('*') << setw(40) << "Initial" << setw(40) << ' ' << endl << endl;
	printVehicles(vList);
	printRequests(rList);
	printZips(zMap);

								// assign vehicles to requests where possible
	resolveRequests(vList, rList, zMap);

								// print solution
	cout << setfill('*') << setw(40) << "Final" << setw(40) << ' ' << endl << endl;
	printVehicles(vList);
	printRequests(rList);

	system("pause");
    return 0;
}

